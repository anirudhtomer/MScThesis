"theta" <-
structure(c(5, 5, 5, 5, 5, 2, 2, 2, 2, 2, -6, -6, -6, -6, -6), .Dim = as.integer(c(5, 
3)))
"mu" <-
c(5, 2, -6)
"tau" <-
c(20, 20, 20)
"tauC" <-
20
