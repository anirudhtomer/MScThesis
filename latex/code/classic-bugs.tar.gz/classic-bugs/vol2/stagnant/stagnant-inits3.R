"alpha" <-
0.47
"beta" <-
c(-0.45, -1)
"tau" <-
5
"x.change" <-
0.5
