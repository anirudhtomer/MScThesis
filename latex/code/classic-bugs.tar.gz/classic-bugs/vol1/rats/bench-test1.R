"benchstats" <-
structure(c(106.395475260000, 6.186341032, 3.59973711728027, 
0.108801811133848, 0.0359973711728027, 0.00108801811133848, 0.0411237269899422, 
0.00135309590786857), .Dim = as.integer(c(2, 4)), .Dimnames = list(
    c("alpha0", "beta.c"), c("Mean", "SD", "Naive SE", "Time-series SE"
    )))
