"alpha0" <-
1
"alpha.Base" <-
0
"alpha.Trt" <-
0
"alpha.BT" <-
0
"alpha.Age" <-
0
"alpha.V4" <-
0
"tau.b1" <-
1
"tau.b" <-
1
